/*
   Aufgabe: Abschlussaufgabe
   Name: Pedja Grba
   Matrikel: 256212
   Datum: 12.02.2018
       
   Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
var abschluss;
(function (abschluss) {
    class MovingStadium {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
        update() {
            this.move();
            this.draw();
        }
        move() {
            //Hallo
        }
        draw() {
            //Hallo
        }
    }
    abschluss.MovingStadium = MovingStadium;
})(abschluss || (abschluss = {}));
//# sourceMappingURL=MovingStadium.js.map